from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.data_loader import load_workbook
from src.field_mapper import suggest_field_mapping
from src.knowledge_loader import KnowledgeBase
from src.report_builder import build_html_report
from src.skill_engine import run_skill

CASES = [
    (
        "distributor_performance_fluctuation",
        ROOT / "data_samples" / "distributor_performance_sample.xlsx",
        "请分析5月华东区经销商业绩下降的主要原因，并提出下一步行动计划。",
    ),
    (
        "subscription_insight",
        ROOT / "data_samples" / "subscription_sample.xlsx",
        "请分析本月订阅业务增长机会在哪里，哪些产品和经销商团队值得优先推动？",
    ),
    (
        "prysm_io_adoption",
        ROOT / "data_samples" / "prysm_io_sample.xlsx",
        "请分析 Prysm IO 的激活和使用情况，以及是否与经销商业绩改善有关。",
    ),
    (
        "community_operation_evaluation",
        ROOT / "data_samples" / "community_operation_sample.xlsx",
        "请评估本期社群陪跑项目是否带来了真实业绩提升，下一期是否值得扩大？",
    ),
    (
        "product_campaign_evaluation",
        ROOT / "data_samples" / "product_campaign_sample.xlsx",
        "请分析某个主推产品或活动是否带来增量，是否存在产品组合机会或蚕食问题。",
    ),
]


def main() -> None:
    kb = KnowledgeBase.load_default(ROOT)
    for skill_id, sample_path, question in CASES:
        context = load_workbook(sample_path)
        mappings = {
            sheet: suggest_field_mapping(sheet, df.columns.astype(str).tolist(), kb.field_aliases)
            for sheet, df in context.sheets.items()
        }
        result = run_skill(skill_id, context, mappings, question, kb)
        assert result.required_sections_complete(), skill_id
        html_path = build_html_report(result, project_root=ROOT)
        assert html_path.exists(), html_path
        print(f"OK {skill_id}: {html_path.name}")


if __name__ == "__main__":
    main()
