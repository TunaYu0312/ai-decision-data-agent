from pathlib import Path

import pandas as pd

from src.auto_agent import auto_select_skill, infer_sheet_roles, prepare_context_for_skill
from src.data_loader import load_workbook
from src.field_mapper import suggest_field_mapping
from src.knowledge_loader import KnowledgeBase
from src.skill_engine import run_skill


def test_unrelated_excel_uses_generic_data_analysis(tmp_path: Path):
    path = tmp_path / "brand_basic_info.xlsx"
    df = pd.DataFrame(
        {
            "品牌名称": ["品牌A", "品牌B", "品牌C"],
            "门店数": [1200, 300, 80],
            "品类类别": ["咖啡", "茶饮", "烘焙"],
            "品牌定位": ["大众", "高端", "社区"],
            "可信度": ["高", "中", "中"],
        }
    )
    with pd.ExcelWriter(path) as writer:
        df.to_excel(writer, sheet_name="品牌基本信息", index=False)

    root = Path(__file__).parents[1]
    kb = KnowledgeBase.load_default(root)
    context = load_workbook(path)
    mappings = {
        sheet: suggest_field_mapping(sheet, table.columns.astype(str).tolist(), kb.field_aliases)
        for sheet, table in context.sheets.items()
    }
    roles = infer_sheet_roles(context, mappings, kb.sheet_schema_catalog)
    selected = auto_select_skill(roles, mappings, kb.skills, kb.sheet_schema_catalog)
    prepared_context, prepared_mappings = prepare_context_for_skill(context, mappings, roles, selected.skill_id)

    result = run_skill(selected.skill_id, prepared_context, prepared_mappings, "请做通用数据分析。", kb)

    assert selected.skill_id == "generic_data_analysis"
    assert result.required_sections_complete()
    assert "通用" in result.skill_name
    assert any(metric.key == "sheet_count" for metric in result.key_metrics)
