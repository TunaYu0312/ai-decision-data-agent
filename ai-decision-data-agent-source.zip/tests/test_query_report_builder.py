from pathlib import Path

import pandas as pd

from src.query_engine import QueryAnswer
from src.query_report_builder import build_query_html_report
from src.report_formatting import markdown_to_html


def test_markdown_to_html_renders_business_markdown():
    html = markdown_to_html(
        """## 直接结论
- **营养A** 是销售主力
- 建议优先复盘活动

| 产品 | 销售额 |
| --- | ---: |
| 营养A | 62000 |
"""
    )

    assert "<h3>直接结论</h3>" in html
    assert "<strong>营养A</strong>" in html
    assert "<table>" in html
    assert "<th>产品</th>" in html


def test_query_report_renders_markdown_and_tables(tmp_path: Path):
    answer = QueryAnswer(
        question="请总结这个数据表的关键发现。",
        answer="## 直接结论\n- **营养A** 是销售主力\n\n## 建议与下一步\n- 优先复盘活动效果",
        evidence=["主要分析 Sheet：product_sales。"],
        limitations=["样本量较小。"],
        tables=[pd.DataFrame({"sheet": ["product_sales"], "rows": [6], "columns": [9]})],
        charts=[{"title": "销售额趋势", "html": "<div>Plotly.newPlot chart</div>"}],
        llm_used=True,
        llm_provider="DeepSeek",
    )

    path = build_query_html_report(answer, project_root=Path.cwd(), output_dir=tmp_path)
    html = path.read_text(encoding="utf-8")

    assert "数据查询分析报告" in html
    assert "关键结论" in html
    assert "<strong>营养A</strong>" in html
    assert "数据结果" in html
    assert "销售额趋势" in html
    assert "Plotly.newPlot chart" in html
    assert "DeepSeek" in html
