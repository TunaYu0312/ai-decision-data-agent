from pathlib import Path

import pandas as pd

from src.data_loader import load_workbook
from src.data_profiler import profile_workbook
from src.field_mapper import suggest_field_mapping, validate_skill_inputs
from src.knowledge_loader import KnowledgeBase
from src.skill_engine import run_skill
from src.report_builder import build_html_report


def _sample_workbook(tmp_path: Path) -> Path:
    path = tmp_path / "sample.xlsx"
    distributor_monthly = pd.DataFrame(
        {
            "月份": ["2026-04", "2026-04", "2026-05", "2026-05"],
            "区域": ["华东", "华东", "华东", "华东"],
            "经销商编号": ["D001", "D002", "D001", "D002"],
            "销售额": [12000, 9000, 9000, 7000],
            "订单数": [120, 90, 80, 70],
            "目标业绩": [11000, 9000, 11000, 9000],
        }
    )
    sales_order = pd.DataFrame(
        {
            "订单ID": ["O1", "O2", "O3", "O4"],
            "订单日期": ["2026-04-05", "2026-04-07", "2026-05-05", "2026-05-08"],
            "月份": ["2026-04", "2026-04", "2026-05", "2026-05"],
            "区域": ["华东", "华东", "华东", "华东"],
            "经销商编号": ["D001", "D002", "D001", "D002"],
            "产品ID": ["P1", "P2", "P1", "P3"],
            "产品类别": ["营养", "护肤", "营养", "家居"],
            "订单金额": [12000, 9000, 9000, 7000],
            "数量": [12, 9, 9, 7],
        }
    )
    product_master = pd.DataFrame(
        {
            "product_id": ["P1", "P2", "P3"],
            "product_name": ["A", "B", "C"],
            "product_category": ["营养", "护肤", "家居"],
        }
    )
    with pd.ExcelWriter(path) as writer:
        distributor_monthly.to_excel(writer, sheet_name="distributor_monthly", index=False)
        sales_order.to_excel(writer, sheet_name="sales_order", index=False)
        product_master.to_excel(writer, sheet_name="product_master", index=False)
    return path


def test_loads_excel_profiles_and_maps_aliases(tmp_path):
    workbook = load_workbook(_sample_workbook(tmp_path))
    profile = profile_workbook(workbook)
    kb = KnowledgeBase.load_default(Path(__file__).parents[1])

    mapping = suggest_field_mapping(
        "sales_order", workbook.sheets["sales_order"].columns.tolist(), kb.field_aliases
    )

    assert sorted(workbook.sheets) == ["distributor_monthly", "product_master", "sales_order"]
    assert profile.sheets["sales_order"].row_count == 4
    assert profile.sheets["sales_order"].column_count == 9
    assert mapping.column_mappings["订单金额"].standard_field == "sales_amount"
    assert mapping.column_mappings["经销商编号"].standard_field == "distributor_id"


def test_validates_required_fields_for_selected_skill(tmp_path):
    workbook = load_workbook(_sample_workbook(tmp_path))
    kb = KnowledgeBase.load_default(Path(__file__).parents[1])
    mappings = {
        sheet: suggest_field_mapping(sheet, df.columns.tolist(), kb.field_aliases)
        for sheet, df in workbook.sheets.items()
    }

    result = validate_skill_inputs(
        "distributor_performance_fluctuation",
        workbook,
        mappings,
        kb.sheet_schema_catalog,
        kb.skills,
    )

    assert result.can_run_full_analysis is True
    assert result.missing_required_sheets == []
    assert result.missing_required_fields == {}


def test_distributor_skill_returns_required_decision_sections(tmp_path):
    project_root = Path(__file__).parents[1]
    workbook = load_workbook(_sample_workbook(tmp_path))
    kb = KnowledgeBase.load_default(project_root)
    mappings = {
        sheet: suggest_field_mapping(sheet, df.columns.tolist(), kb.field_aliases)
        for sheet, df in workbook.sheets.items()
    }

    result = run_skill(
        "distributor_performance_fluctuation",
        workbook,
        mappings,
        "请分析5月华东区经销商业绩下降的主要原因，并提出下一步行动计划。",
        kb,
    )

    assert result.skill_id == "distributor_performance_fluctuation"
    assert result.decision_options
    assert result.recommended_decision
    assert result.action_plan
    assert result.kpi_tracking
    assert result.review_plan
    assert "销售额" in result.executive_summary


def test_html_report_is_exported(tmp_path):
    project_root = Path(__file__).parents[1]
    workbook = load_workbook(_sample_workbook(tmp_path))
    kb = KnowledgeBase.load_default(project_root)
    mappings = {
        sheet: suggest_field_mapping(sheet, df.columns.tolist(), kb.field_aliases)
        for sheet, df in workbook.sheets.items()
    }
    result = run_skill(
        "distributor_performance_fluctuation",
        workbook,
        mappings,
        "请分析5月华东区经销商业绩下降的主要原因，并提出下一步行动计划。",
        kb,
    )

    html_path = build_html_report(result, project_root=project_root, output_dir=tmp_path)

    assert html_path.exists()
    html = html_path.read_text(encoding="utf-8")
    assert "Decision Options" in html
    assert "plotly" in html.lower()
