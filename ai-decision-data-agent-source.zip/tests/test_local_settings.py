from src.local_settings import load_local_env, save_local_env


def test_save_and_load_local_env(tmp_path):
    path = save_local_env(
        tmp_path,
        {
            "LLM_PROVIDER": "DeepSeek",
            "LLM_BASE_URL": "https://api.deepseek.com",
            "LLM_MODEL": "deepseek-chat",
            "LLM_API_KEY": "test-key",
            "LLM_ENABLED": "true",
            "WEB_SEARCH_ENABLED": "true",
            "WEB_SEARCH_PROVIDER": "Tavily",
            "WEB_SEARCH_API_KEY": "search-key",
        },
    )

    values = load_local_env(tmp_path)

    assert path.name == ".env.local"
    assert values["LLM_PROVIDER"] == "DeepSeek"
    assert values["LLM_API_KEY"] == "test-key"
    assert values["LLM_ENABLED"] == "true"
    assert values["WEB_SEARCH_ENABLED"] == "true"
    assert values["WEB_SEARCH_PROVIDER"] == "Tavily"
