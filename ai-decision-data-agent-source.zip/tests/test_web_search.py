from src.web_search import WebSearchConfig, search_web, web_results_to_prompt


class FakeResponse:
    text = """
    <div class="result">
      <a class="result__a" href="https://example.com/a">Example A</a>
      <a class="result__snippet">Example snippet A</a>
    </div></div>
    """

    def raise_for_status(self):
        return None

    def json(self):
        return {
            "results": [
                {"title": "Result A", "url": "https://example.com/a", "content": "Summary A"},
                {"title": "Result B", "url": "https://example.com/b", "content": "Summary B"},
            ]
        }


def test_tavily_search_parses_results():
    captured = {}

    def fake_post(url, json, timeout):
        captured["url"] = url
        captured["json"] = json
        return FakeResponse()

    results = search_web(
        "latest brand news",
        WebSearchConfig(enabled=True, provider="Tavily", api_key="key", max_results=1),
        post_func=fake_post,
    )

    assert captured["url"] == "https://api.tavily.com/search"
    assert captured["json"]["query"] == "latest brand news"
    assert results[0].title == "Result A"
    assert "Summary A" in web_results_to_prompt(results)


def test_duckduckgo_search_parses_results():
    def fake_get(url, params, headers, timeout):
        return FakeResponse()

    results = search_web(
        "latest brand news",
        WebSearchConfig(enabled=True, provider="DuckDuckGo", max_results=1),
        get_func=fake_get,
    )

    assert results[0].title == "Example A"
    assert results[0].url == "https://example.com/a"
