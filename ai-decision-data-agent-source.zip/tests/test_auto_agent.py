from pathlib import Path

import pandas as pd

from src.auto_agent import auto_select_skill, infer_sheet_roles, prepare_context_for_skill
from src.data_loader import load_workbook
from src.field_mapper import suggest_field_mapping
from src.knowledge_loader import KnowledgeBase


def test_auto_agent_infers_roles_from_nonstandard_excel(tmp_path: Path):
    path = tmp_path / "业务数据.xlsx"
    monthly = pd.DataFrame(
        {
            "月份": ["2026-04", "2026-05"],
            "区域": ["华东", "华东"],
            "直销员ID": ["D001", "D001"],
            "业绩": [12000, 9000],
            "单数": [120, 80],
        }
    )
    orders = pd.DataFrame(
        {
            "订单编号": ["O1", "O2"],
            "下单日期": ["2026-04-03", "2026-05-03"],
            "月份": ["2026-04", "2026-05"],
            "大区": ["华东", "华东"],
            "直销员ID": ["D001", "D001"],
            "sku_id": ["P1", "P2"],
            "品类": ["营养", "护肤"],
            "订单金额": [12000, 9000],
        }
    )
    products = pd.DataFrame({"sku_id": ["P1", "P2"], "商品名称": ["A", "B"], "品类": ["营养", "护肤"]})
    with pd.ExcelWriter(path) as writer:
        monthly.to_excel(writer, sheet_name="月度业绩明细", index=False)
        orders.to_excel(writer, sheet_name="订单流水", index=False)
        products.to_excel(writer, sheet_name="产品资料", index=False)

    kb = KnowledgeBase.load_default(Path(__file__).parents[1])
    context = load_workbook(path)
    mappings = {
        sheet: suggest_field_mapping(sheet, df.columns.astype(str).tolist(), kb.field_aliases)
        for sheet, df in context.sheets.items()
    }

    roles = infer_sheet_roles(context, mappings, kb.sheet_schema_catalog)
    selected = auto_select_skill(roles, mappings, kb.skills, kb.sheet_schema_catalog)
    prepared_context, prepared_mappings = prepare_context_for_skill(context, mappings, roles, selected.skill_id)

    assert roles["月度业绩明细"].role == "distributor_monthly"
    assert roles["订单流水"].role == "sales_order"
    assert selected.skill_id == "distributor_performance_fluctuation"
    assert "distributor_monthly" in prepared_context.sheets
    assert "sales_order" in prepared_context.sheets
    assert prepared_mappings["sales_order"].column_mappings["订单金额"].standard_field == "sales_amount"
