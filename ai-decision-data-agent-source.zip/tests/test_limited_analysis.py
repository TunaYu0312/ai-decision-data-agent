from pathlib import Path

import pandas as pd

from src.data_loader import load_workbook
from src.field_mapper import suggest_field_mapping
from src.knowledge_loader import KnowledgeBase
from src.skill_engine import run_skill


def test_community_skill_degrades_when_monthly_lacks_distributor_id(tmp_path: Path):
    path = tmp_path / "limited_community.xlsx"
    project = pd.DataFrame(
        {
            "community_project_id": ["CP001"],
            "project_name": ["测试陪跑"],
            "start_date": ["2026-05-01"],
            "end_date": ["2026-05-31"],
        }
    )
    participant = pd.DataFrame(
        {
            "community_project_id": ["CP001", "CP001"],
            "distributor_id": ["D001", "D002"],
            "treatment_flag": [1, 0],
            "control_group_flag": [0, 1],
            "participation_level": ["高", "对照"],
        }
    )
    monthly_without_distributor = pd.DataFrame(
        {
            "month": ["2026-04", "2026-05"],
            "region": ["华东", "华东"],
            "sales_amount": [10000, 12000],
            "order_count": [100, 110],
        }
    )
    with pd.ExcelWriter(path) as writer:
        project.to_excel(writer, sheet_name="community_project", index=False)
        participant.to_excel(writer, sheet_name="community_participant", index=False)
        monthly_without_distributor.to_excel(writer, sheet_name="distributor_monthly", index=False)

    root = Path(__file__).parents[1]
    kb = KnowledgeBase.load_default(root)
    context = load_workbook(path)
    mappings = {
        sheet: suggest_field_mapping(sheet, df.columns.astype(str).tolist(), kb.field_aliases)
        for sheet, df in context.sheets.items()
    }

    result = run_skill(
        "community_operation_evaluation",
        context,
        mappings,
        "请评估社群陪跑是否有效。",
        kb,
    )

    assert result.required_sections_complete()
    assert "缺少" in result.key_findings[0]
