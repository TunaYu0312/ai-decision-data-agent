from pathlib import Path

import pandas as pd

from src.data_loader import load_workbook
from src.llm_client import LLMConfig, deepseek_enhance_query, enhance_query_with_llm
from src.query_engine import query_workbook


class FakeResponse:
    def raise_for_status(self):
        return None

    def json(self):
        return {"choices": [{"message": {"content": "LLM增强结论：优先关注品牌A和品牌C。"}}]}


def test_deepseek_enhancement_uses_openai_compatible_chat_payload(tmp_path: Path):
    path = tmp_path / "brands.xlsx"
    pd.DataFrame({"品牌名称": ["品牌A", "品牌C"], "门店数": [1500, 900]}).to_excel(path, index=False)
    context = load_workbook(path)
    answer = query_workbook(context, "目前发展比较健康的连锁品牌有哪几个？")
    captured = {}

    def fake_post(url, headers, json, timeout):
        captured["url"] = url
        captured["headers"] = headers
        captured["json"] = json
        captured["timeout"] = timeout
        return FakeResponse()

    enhanced = deepseek_enhance_query(
        context,
        "目前发展比较健康的连锁品牌有哪几个？",
        answer,
        api_key="test-key",
        post_func=fake_post,
    )

    assert captured["url"] == "https://api.deepseek.com/chat/completions"
    assert captured["json"]["model"] == "deepseek-chat"
    assert "LLM增强结论" in enhanced.answer
    assert enhanced.llm_used is True


def test_generic_openai_compatible_provider_uses_configured_base_url(tmp_path: Path):
    path = tmp_path / "brands.xlsx"
    pd.DataFrame({"品牌名称": ["品牌A"], "门店数": [1500]}).to_excel(path, index=False)
    context = load_workbook(path)
    answer = query_workbook(context, "目前发展比较健康的连锁品牌有哪几个？")
    captured = {}

    def fake_post(url, headers, json, timeout):
        captured["url"] = url
        captured["json"] = json
        return FakeResponse()

    enhanced = enhance_query_with_llm(
        context,
        "目前发展比较健康的连锁品牌有哪几个？",
        answer,
        LLMConfig("Custom", "key", "https://example.com/v1", "custom-model", True),
        post_func=fake_post,
    )

    assert captured["url"] == "https://example.com/v1/chat/completions"
    assert captured["json"]["model"] == "custom-model"
    assert enhanced.llm_provider == "Custom"
