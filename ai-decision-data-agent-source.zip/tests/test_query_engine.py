from pathlib import Path

import pandas as pd

from src.data_loader import load_workbook
from src.query_engine import query_workbook


def _brand_file(tmp_path: Path) -> Path:
    path = tmp_path / "brands.xlsx"
    df = pd.DataFrame(
        {
            "品牌名称": ["品牌A", "品牌B", "品牌C", "品牌D"],
            "门店数": [1500, 280, 900, 80],
            "品类类别": ["咖啡", "茶饮", "咖啡", "烘焙"],
            "最新现状": ["扩张稳定", "增长放缓", "持续增长", "调整收缩"],
            "当前主要策略": ["加盟扩张", "产品升级", "下沉市场", ""],
            "品牌定位": ["大众", "高端", "大众", "社区"],
            "面临的挑战": ["竞争加剧", "成本压力", "", "门店关闭"],
            "是否上市": ["是", "否", "是", "否"],
            "可信度": ["高", "中", "高", "中"],
        }
    )
    with pd.ExcelWriter(path) as writer:
        df.to_excel(writer, sheet_name="品牌基本信息", index=False)
    return path


def test_query_workbook_ranks_healthy_chain_brands(tmp_path: Path):
    context = load_workbook(_brand_file(tmp_path))

    answer = query_workbook(context, "目前发展比较健康的连锁品牌有哪几个？")

    assert "品牌A" in answer.answer
    assert "品牌C" in answer.answer
    assert answer.tables
    assert "health_score" in answer.tables[0].columns


def test_query_workbook_refuses_stock_growth_without_stock_fields(tmp_path: Path):
    context = load_workbook(_brand_file(tmp_path))

    answer = query_workbook(context, "上市的品牌中，哪几个品牌目前股票增长比较顺利？")

    assert "无法判断股票增长" in answer.answer
    assert "缺少" in answer.limitations[0]
    assert answer.tables


def test_query_workbook_parses_store_count_text_for_health_score(tmp_path: Path):
    path = tmp_path / "brands_text_store.xlsx"
    df = pd.DataFrame(
        {
            "品牌名称": ["强势品牌", "弱势品牌"],
            "门店数": ["30158家（2025年底）", "41家（2025年）"],
            "最新现状": ["持续增长", "持续收缩"],
            "当前主要策略": ["扩张", "关闭门店"],
            "面临的挑战": ["竞争", "经营异常"],
            "可信度": ["高", "高"],
        }
    )
    with pd.ExcelWriter(path) as writer:
        df.to_excel(writer, sheet_name="品牌基本信息", index=False)

    answer = query_workbook(load_workbook(path), "行业发展比较好的品牌有哪几个")
    table = answer.tables[0]

    strong_score = float(table.loc[table["brand"] == "强势品牌", "health_score"].iloc[0])
    weak_score = float(table.loc[table["brand"] == "弱势品牌", "health_score"].iloc[0])
    assert strong_score > weak_score


def test_generic_industry_report_returns_insights_not_only_profile(tmp_path: Path):
    context = load_workbook(_brand_file(tmp_path))

    answer = query_workbook(context, "根据这个数据输出行业洞察报告")

    assert "直接结论" in answer.answer
    assert "建议与下一步" in answer.answer
    assert "数据结构概览" not in answer.answer
    assert len(answer.tables) >= 2
    assert answer.charts


def test_query_workbook_generates_trend_chart_when_time_series_exists(tmp_path: Path):
    path = tmp_path / "trend.xlsx"
    df = pd.DataFrame(
        {
            "month": ["2026-01", "2026-02", "2026-03", "2026-01", "2026-02", "2026-03"],
            "product_category": ["营养", "营养", "营养", "护肤", "护肤", "护肤"],
            "sales_amount": [100, 130, 160, 80, 70, 120],
        }
    )
    with pd.ExcelWriter(path) as writer:
        df.to_excel(writer, sheet_name="product_sales", index=False)

    answer = query_workbook(load_workbook(path), "请分析销售趋势")

    assert any("趋势" in chart["title"] for chart in answer.charts)
    assert "Plotly.newPlot" in answer.charts[0]["html"]
